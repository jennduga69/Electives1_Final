package net.flood.ocrnn.ui;

/**
 * @author flood2d
 */
public interface Animation {

    void animate(long deltaMs);
}
